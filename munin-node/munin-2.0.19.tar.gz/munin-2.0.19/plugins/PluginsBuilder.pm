package PluginsBuilder;

# $Id$

use base qw(Module::Build);

use lib '../common/lib';

use warnings;
use strict;

1;
