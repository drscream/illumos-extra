/* On PowerPC __sync_lock_test_and_set isn't a full barrier.  */
#include "config/linux/ia64/mutex.h"
